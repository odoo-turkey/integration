package com.gt.example.servlets;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import sun.misc.BASE64Encoder;

/**
 * Servlet implementation class Gate3DEngineCallBack
 */
public class Gate3DEngineCallBack extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected BASE64Encoder B64ENC = new BASE64Encoder();
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Gate3DEngineCallBack() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response) {
		System.out.println( "Validation : " + this.validateHash(request));
	}

	private boolean validateHash(HttpServletRequest request) {
		String responseHashparams = request.getParameter("hashparams");
		String responseHashparamsval = request.getParameter("hashparamsval");
		String responseHash = request.getParameter("hash");
		String storekey = "XXXXXXXX"; //TODO STORE KEY OF TERMINAL 
		 
		System.out.println("RESPONSE HASHPARAMS :[" + responseHashparams + "]");
		System.out.println("RESPONSE HASHPARAMSVAL :[" + responseHashparamsval + "]");
		System.out.println("RESPONSE HASH :[" + responseHash + "]");
		
		if (responseHashparams!=null &&  !"".equals(responseHashparams)){
			String digestData = "";
			String paramList[] = responseHashparams.split(":");
			System.out.println("RESPONSE ParamList:");
			for (String param : paramList) {
				System.out.println("[" + param + "] value : [" + request.getParameter(param) + "]");
				digestData +=  request.getParameter(param) == null ? "" : request.getParameter(param);  
			}
			System.out.println("CALCULATED digestData = ["+ digestData +"]");
			String hashCalculated = macsha1(digestData + storekey );
			System.out.println("CALCULATED HASH : ["+ hashCalculated +"]");
			
			if(responseHash.equals(hashCalculated)){
				System.out.println("!!!!!HASH VALID!!!!!");
				return true;
			}else{
				System.out.println("!!!!!HASH INVALID!!!!!");	
				System.out.println("RESPONSE HASH : [" + responseHash + "]");
				System.out.println("CALCULATED HASH : ["+ hashCalculated +"]");
			}
		}else{
			System.out.println("!!!!!FATAL ERROR/INTEGRATION ERROR!!!!!");
			System.out.println("response :" +request.getParameter("response"));
			System.out.println("procreturncode :" + request.getParameter("procreturncode"));
			System.out.println("mderrormessage :" + request.getParameter("mderrormessage"));
		}
		return false;

	}

	private void logRequestParams(HttpServletRequest request) {
		Map params = request.getParameterMap();
		Iterator i = params.keySet().iterator();
		System.out.println("##############################################################################");
		while (i.hasNext()) {
			String key = (String) i.next();
			String value = ((String[]) params.get(key))[0];
			System.out.println("[" + key + "]=[" + value + "]");			
		}
		System.out.println("##############################################################################");
	}
	
	public String macsha1(String hashdata) {
		String returnText = "";
		MessageDigest sha1 = null;
		try {
			sha1 = MessageDigest.getInstance("SHA-1");
			sha1.update(hashdata.getBytes());
			returnText = B64ENC.encode(sha1.digest());
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return returnText;
	}

}
